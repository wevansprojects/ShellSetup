#!/bin/bash
function zshcheck(){
shelltype=$(echo $SHELL)
if [[ $shelltype == '/bin/zsh' ]]; then 
whiptail --title "Zsh Deployment " --msgbox "Zsh Shell Detected No Deployment Required " 0 0 3>&1 1>&2 2>&3
MainMenu
else 
zshelldeploy
fi
}

function osdetails()
{
clear      
result=$(hostnamectl);
whiptail --title "Host Information " --msgbox "$result" 0 0 3>&1 1>&2 2>&3
MainMenu
}
#sudo chsh -s /bin/zsh

function zshelldeploy(){
redhat=$(whereis dnf|cut -d ":" -f2|cut -d" " -f2 ) 
if [[ -f $redhat ]]; then
echo "This is a Red Hat Based System"
sudo dnf install git 
sudo dnf install wget
cd $HOME/Downloads
echo "Downloading zsh Setup Scripts"
cd $HOME/Downloads/SystemSetupGui/ZShSetup
tar xzf ZshSetup.tar.gz 
distro=$(cat /etc/os-release |grep '^ID='|cut -d "=" -f2)
cd $HOME/Downloads/SystemSetupGui/ZShSetup/ConfigFiles/P10kConfigs
mv Fedora fedora
mv PopOS pop
mv Rocky rocky
clear
cd $HOME/Downloads/SystemSetupGui/ZShSetup
./'ZshSetup Fedora.sh'
cd $HOME/Downloads/SystemSetupGui/ZShSetup/ConfigFiles/P10kConfigs/$distro
cp .p10k.zsh "$HOME"
sudo chsh -s /bin/zsh
whiptail --title "Zsh Deployment " --msgbox "Zsh Deployment is finished. Final Steps: You will need to change you're /etc/passwd file edit the user change from /bin/bash to /bin/zsh. Restart your machine and this completes the setup. " 0 0 3>&1 1>&2 2>&3
MainMenu
else 
echo "This is a Debian Based System"
sudo apt install git 
sudo apt install wget
cd $HOME/Downloads
echo "Downloading zsh Setup Scripts"
cd $HOME/Downloads/SystemSetupGui/ZShSetup
tar xzf ZshSetup.tar.gz 
clear
distro=$(cat /etc/os-release |grep '^ID='|cut -d "=" -f2)
cd $HOME/Downloads/SystemSetupGui/ZShSetup/ConfigFiles/P10kConfigs
mv Fedora fedora
mv PopOS pop
mv Rocky rocky
clear
cd $HOME/Downloads/SystemSetupGui/ZShSetup
./'ZshSetup Ubuntu.sh'
cd $HOME/Downloads/SystemSetupGui/ZShSetup/ConfigFiles/P10kConfigs/$distro
cp .p10k.zsh "$HOME"
sudo chsh -s /bin/zsh
whiptail --title "Zsh Deployment " --msgbox "Zsh Deployment is finished. Final Steps: You will need to change you're /etc/passwd file edit the user change from /bin/bash to /bin/zsh. Restart your machine and this completes the setup. " 0 0 3>&1 1>&2 2>&3
MainMenu
fi
}

function nerdfonts(){
whiptail --title "Nerd Font Downloads " --msgbox "Installing Fonts From https://www.nerdfonts.com/font-downloads" 0 0 3>&1 1>&2 2>&3
./nerdfontsinstall.sh
MainMenu
}

function ZshellsetupMenu (){
 MNU=$(whiptail --title ":Zsh Deployment:" --menu "Select options" 15 60 8 \
"1" "Download Nerd Fonts" \
"2" "ZShell Deployment" \
"3"  "Main Menu" 3>&1 1>&2 2>&3)

case $MNU in
     1)nerdfonts;;
     2)zshcheck;;
     3)MainMenu;;
esac
}

function MainMenu() {
 MNU=$(whiptail --title ":Zsh Custom Shell Setup Menu:" --menu "Select options" 15 60 8 \
"1" "Host Information" \
"2" "ZShell Custom Shell Deployment" \
"3"  "Exit" 3>&1 1>&2 2>&3)

case $MNU in
     1)osdetails;;
     2)ZshellsetupMenu;;\
     3)exit 0;;
esac
}
MainMenu

