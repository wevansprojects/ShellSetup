#!/bin/bash
function ycompletechecker (){
jvacchck=$(javac --version |cut -d ' ' -f2)
javacchck=$(java --version|cut -d ' ' -f2|head -1)       
gpluchck=$(g++ --version|cut -d')' -f2|head -1|cut -d' ' -f2) 
pipchck=$(pip --version|cut -d ' ' -f2)
pychck=$(python3 -V|cut -d ' ' -f2)      
if [ -z $jvacchck ] || [ -z $javacchck ] || [ -z $gpluchck ] || [ -z $pychck ] ||[ -z $pipchck ] ; then
whiptail --title "Vim Plugin Deployment:" --title "Vim Plugin Deployment" --msgbox "One or more required items is NOT Installed. Please ensure you have the following downloaded. Java v17+ Python 3.7+ pip3 g++" 0 0 3>&1 1>&2 2>&3
else 
echo "Its All Good"
fi
}
ycompletechecker
