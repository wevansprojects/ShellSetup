#!/bin/bash
function vimcheck(){
vimalecheck=$(ls $HOME/.vim/autoload/plugged|grep 'ale')
if [[ -f $vimalecheck ]]; then 
whiptail --title "Vim Plugin Deployment " --msgbox "Vim Plugins Deployed No Further Action Required." 0 0 3>&1 1>&2 2>&3
MainMenu
else 
vimplugindeploy
fi
}

function osdetails()
{
clear      
result=$(hostnamectl);
whiptail --title "Host Information " --msgbox "$result" 0 0 3>&1 1>&2 2>&3
MainMenu
}

function vimplugindeploy(){
redhat=$(whereis dnf|cut -d ":" -f2|cut -d" " -f2 ) 
if [[ -f $redhat ]]; then
echo "This is a Red Hat Based System"
sudo dnf install git 
sudo dnf install wget
cd $HOME/Downloads
cd $HOME/Downloads/SystemSetupGui/VimSetup
tar xzf FedoraVim.tar.gz 
clear
cd $HOME/Downloads/SystemSetupGui/VimSetup
./'vimpluginsetup.sh'
whiptail --title "Vim Plugin Deployment" --msgbox "The Vim Plugin Tool is now available. Please open up vim and in command mode : type PlugInstall this will allow Vim to install the plugins." 0 0 3>&1 1>&2 2>&3
MainMenu
else 
echo "This is a Debian Based System"
sudo apt install git 
sudo apt install wget
cd $HOME/Downloads/SystemSetupGui/VimSetup
tar xzf UbuntuVim.tar.gz 
clear
cd $HOME/Downloads/SystemSetupGui/VimSetup
./'Ubuntuvimpluginsetup.sh'
whiptail --title "Vim Plugin Deployment" --msgbox "The Vim Plugin Tool is now available. Please open up vim and in command mode : type PlugInstall this will allow Vim to install the plugins." 0 0 3>&1 1>&2 2>&3
MainMenu
fi
}

function nerdfonts(){
whiptail --title "Nerd Font Downloads " --msgbox "Installing Fonts From https://www.nerdfonts.com/font-downloads" 0 0 3>&1 1>&2 2>&3
./nerdfontsinstall.sh
MainMenu
}

function fzfenable (){
cd $HOME/.vim/autoload/plugged/fzf
./install     
whiptail --title "Vim Plugin Deployment" --msgbox "The Vim Plugin Fuzzy Finder has been installed. Please close you're terminal and re-open it to make use of the plugin" 0 0 3>&1 1>&2 2>&3
MainMenu
}

function ycompletechecker (){
jvacchck=$(javac --version |cut -d ' ' -f2)
javacchck=$(java --version|cut -d ' ' -f2|head -1)       
gpluchck=$(g++ --version|cut -d')' -f2|head -1|cut -d' ' -f2) 
pipchck=$(pip --version|cut -d ' ' -f2)
pychck=$(python3 -V|cut -d ' ' -f2)      
if [ -z $jvacchck ] || [ -z $javacchck ] || [ -z $gpluchck ] || [ -z $pychck ] ||[ -z $pipchck ] ; then
whiptail --title "Vim Plugin Deployment:" --title "Vim Plugin Deployment" --msgbox "One or more required items is NOT Installed. Please ensure you have the following downloaded. Java v17+ Python 3.7+ pip3 g++" 0 0 3>&1 1>&2 2>&3
MainMenu
else 
ycompmeenable
fi
}


function ycompmeenable (){
cd $HOME/.vim/autoload/plugged/YouCompleteMe
python3 ./install.py --all
MainMenu
}

function Zshellsetup(){
./ZShSetup.sh
}

function VimpluginsetupMenu (){
 MNU=$(whiptail --title ":Vim Plugin Deployment:" --menu "Select options" 15 60 8 \
"1" "Download Nerd Fonts" \
"2" "Deploy Vim Plugin Tool" \
"3" "Enable fzf Vim Plugin" \
"4" "Enable You CompleteMe Vim Plugin" \
"5"  "Main Menu" 3>&1 1>&2 2>&3)

case $MNU in
     1)nerdfonts;;
     2)vimcheck;;
     3)fzfenable;;
     4)ycompletechecker;;
     5)MainMenu;;
esac
}

function MainMenu() {
 MNU=$(whiptail --title ":Vim Plugin Deployment Setup Menu:" --menu "Select options" 15 60 8 \
"1" "Host Information" \
"2" "VimPlugin Deployment" \
"3" "ZShell Custom Shell Deployment" \
"4"  "Exit" 3>&1 1>&2 2>&3)

case $MNU in
     1)osdetails;;
     2)VimpluginsetupMenu;;\
     3)Zshellsetup;;
     4)exit 0;;
esac
}
MainMenu

