#!/bin/bash
function systemcheck () {
redhat=$(whereis dnf|cut -d ":" -f2|cut -d" " -f2 ) 
if [[ -f $redhat ]]; then
#echo "This is a Red Hat Based System"
rhnfcheck
else
#echo "This is a Debian Based System"
dbnfcheck
fi
}
function rhnfcheck () {
rhnerdfontsinst=$(ls /usr/share/fonts | grep 'meslo'|cut -d"-" -f1 )
if [[ -z "$rhnerdfontsinst"  ]]; then
echo "No Nerd Fonts Detected Installing ..."
    nerdfontsredhat
   whiptail --title "Nerd Font Downloads " --msgbox "Done! set you're terminal to use Font: Meslo LG S Regular Nerd Font  " 0 0 3>&1 1>&2 2>&3
e
else
    echo "Nerd Fonts Installed Exiting..."
   whiptail --title "Nerd Font Downloads " --msgbox "Done! set you're terminal to use Font: Meslo LG S Regular Nerd Font  " 0 0 3>&1 1>&2 2>&3
    exit 0   
fi
}

function dbnfcheck () {
debnerdfontsinst=$(ls "$HOME/.local/share/fonts/Unknown vendor/OpenType/FuraMono Nerd Font"| grep 'Fura'|cut -d"-" -f1 )

if [[ -z "$debnerdfontsinst"  ]]; then
echo "No Nerd Fonts Detected Installing ..."
   nerdfontsdebian
   whiptail --title "Nerd Font Downloads " --msgbox "Done! set you're terminal to use Font: FuraMono Nerd Font " 0 0 3>&1 1>&2 2>&3
else
    echo "Nerd Fonts Installed Exiting..."
   whiptail --title "Nerd Font Downloads " --msgbox "Done! set you're terminal to use Font: FuraMono Nerd Font " 0 0 3>&1 1>&2 2>&3
exit 0   
fi
}

function nerdfontsredhat(){
cd $HOME/Downloads
echo "Downloading Nerd Fonts for this system"
cd $HOME/Downloads
wget https://github.com/ryanoasis/nerd-fonts/releases/download/v2.3.3/Meslo.zip
mkdir meslo-nerd-fonts
unzip -j "Meslo.zip" "Meslo LG S Regular Nerd Font Complete.ttf" -d "$HOME/Downloads/meslo-nerd-fonts"
rm Meslo.zip
sudo cp -r meslo-nerd-fonts /usr/share/fonts
sudo chmod -R 0755 /usr/share/fonts/meslo-nerd-fonts
echo "Done Nerd Fonts Now Installed. Please change you're terminal fonts to make meslo-nerd-fonts the default profile font"
rm -rf $HOME/Downloads/meslo-nerd-fonts 
clear
}

function nerdfontsdebian(){
cd $HOME/Downloads
echo "Downloading Nerd Fonts for this system"
cd $HOME/Downloads
wget https://github.com/ryanoasis/nerd-fonts/releases/download/v2.3.3/FiraMono.zip
mkdir "$HOME/.local/share/fonts"
mkdir "$HOME/.local/share/fonts/Unknown vendor"
mkdir "$HOME/.local/share/fonts/Unknown vendor/OpenType"
mkdir "$HOME/.local/share/fonts/Unknown vendor/OpenType/FuraMono Nerd Font"

unzip -j "$HOME/Downloads/FiraMono.zip" "Fura Mono Regular Nerd Font Complete.otf" -d "$HOME/.local/share/fonts/Unknown vendor/OpenType/FuraMono Nerd Font"

rm FiraMono.zip
sudo fc-cache -fv
echo "Done Nerd Fonts Now Installed. Please change you're terminal fonts to make meslo-nerd-fonts the default profile font"
clear
}

systemcheck
