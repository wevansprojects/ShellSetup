#!/bin/bash

function SSHOnServer()
{
clear      
sudo /home/wevans/Scripts/Bash/SysAdminMenu/sshsetup/server/./serversshwarning.sh
SSHSetupMenuHome
}

function SSHOnClientNewKey()
{
clear      
sudo /home/wevans/Scripts/Bash/SysAdminMenu/sshsetup/client/./clientssh-newkey.sh
SSHSetupMenuHome
}

function SSHSetupMenuHome(){
 MNU=$(whiptail --title ":SSH Setup Menu:" --menu "Select options" 15 60 8 \
"1" "Setup SSH On Server" \
"2" "Setup SSH On Client" \
"5" "Exit"   3>&1 1>&2 2>&3)

case $MNU in
     1)SSHOnServer;;
     2)SSHOnClient;;
     3)exit;;

esac
}

function SSHOnClient() {
 MNU=$(whiptail --title ":Setup SSH On Client System:" --menu "Select options" 15 60 8 \
"1" "Create a New SSH Client Key" \
"2" "Link Client SSH Key to Server" \
"3" "Back To Main Menu" \
"4" "Exit" 3>&1 1>&2 2>&3)

case $MNU in
     1)SSHOnServer;;
     2)SSHOnClientNewKey;;
     3)SSHSetupMenuHome;;
     4)exit 0;;
esac
}
SSHSetupMenuHome
