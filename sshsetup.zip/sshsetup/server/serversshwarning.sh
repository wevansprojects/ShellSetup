#!/bin/bash

echo ":The script currently only supports RedHat and Debian based Servers"
echo "Please note the following:"
echo "1. Make sure you have SSH Server already client installed"
echo "2. Make sure the firewall is enabled"
echo "4. The script is set in stone all settings are predefined"
echo "5. The script will override any existing SSH config settings"
printf "\n"
read -p ":Is The System Rehat Based Y/N: " input
if [ $input == "Y" ]; then
      echo "Setting Up SSH Access On Redhat based Server"
	clear
	exec ~/Scripts/Bash/SysAdminMenu/sshsetup/server/serverssh-prep.sh
elif [ $input == "N" ]; then
      echo "Setting Up SSH Access On Debian based Server"
	clear
	exec ~/Scripts/Bash/SysAdminMenu/sshsetup/server/serverssh-prepubuntu.sh
fi
