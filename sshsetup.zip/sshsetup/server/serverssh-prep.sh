#!/bin/bash
echo "This Script will prepare the Server for SSH"
echo "Note it is assumed SSH Server and client are already installed"
printf "\n"

echo "Adding a unique port for ssh in the firewall"
echo "We are assuming the default firewall is public"
printf "\n"

sudo firewall-cmd --add-port=49155/tcp --permanent
printf "\n"

echo "Firewall Change See Below"
sudo firewall-cmd --zone=public --list-all
printf "\n"
echo "Backup Old SSH File and Replace It"
cd /etc/ssh
sudo cp sshd_config ssh_config_old
cd /home/$USER 
touch sshd_config
rm sshd_config
echo "Include /etc/ssh/sshd_config.d/*.conf" >> sshd_config
echo "Port 49155" >> sshd_config
echo "PermitRootLogin no" >> sshd_config
echo "AuthorizedKeysFile      .ssh/authorized_keys" >> sshd_config
echo "PermitEmptyPasswords yes" >> sshd_config
echo "UsePAM yes" >> sshd_config
echo "X11Forwarding no" >> sshd_config
echo "Subsystem       sftp    /usr/libexec/openssh/sftp-server" >> sshd_config

sudo mv sshd_config /etc/ssh/
sudo chmod 600 /etc/ssh/sshd_config

